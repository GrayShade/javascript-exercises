This exercise is tricky and was removed from our recommendations because it mostly leverages regular expressions for the solution, and those aren't really taught at this point in our curriculum.

Leaving it here for posterity, or a good challenge for anyone that wants to give it a shot.

Pig Latin is a children's language that is intended to be confusing when spoken quickly. Your job for this exercise is to create a solution that takes the words given and
turns them into pig latin. Please see the following wikipedia page for details regarding the rules of Pig Latin:

https://en.wikipedia.org/wiki/Pig_Latin

The rules section will give the rules and the examples that are required to complete this exercise.
